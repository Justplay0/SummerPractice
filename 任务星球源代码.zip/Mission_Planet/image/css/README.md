### QT StyleSheet templates ###
Themes available:
1. [Ubuntu](https://github.com/GTRONICK/QSS/blob/master/Ubuntu.qss)

![Ubuntu theme screenshot](https://i.imgur.com/i8zVYwL.png)
    
2. [ElegantDark](https://github.com/GTRONICK/QSS/blob/master/ElegantDark.qss)

![ElegantDark theme screenshot](https://i.imgur.com/AUb7R7P.png)
    
3. [MaterialDark](https://github.com/GTRONICK/QSS/blob/master/MaterialDark.qss)

![MaterialDark theme screenshot](https://i.imgur.com/ViEQxdh.png)
    
4. [ConsoleStyle](https://github.com/GTRONICK/QSS/blob/master/ConsoleStyle.qss)

![ConsoleStyle theme screenshot](https://i.imgur.com/E10ukaA.png)
    
5. [AMOLED](https://github.com/GTRONICK/QSS/blob/master/AMOLED.qss)

![AMOLED theme screenshot](https://i.imgur.com/M7RIx4c.png)
    
6. [Aqua](https://github.com/GTRONICK/QSS/blob/master/Aqua.qss)

![Aqua theme screenshot](https://i.imgur.com/i8zVYwL.png)

## The ManjaroMix Theme!: Includes a radial gradient for Checkboxes, and minimalist arrows for scrollbars. ##
7. [ManjaroMix](https://github.com/GTRONICK/QSS/blob/master/ManjaroMix.qss)

![ManjaroMix theme screenshot](https://i.imgur.com/7zrMDMH.png)

8. [NeonButtons](https://github.com/GTRONICK/QSS/blob/master/NeonButtons.qss)

![NeonButtons screenshot](https://i.imgur.com/IqTSQG2.png)
![NeonButtons screenshot](https://i.imgur.com/l4im5Ve.png)

## MacOS Theme!: Reduced code, image integration through URL resources. ##
9. [MacOS](https://github.com/GTRONICK/QSS/blob/master/MacOS.qss)

![MacOS](https://i.imgur.com/quEgiVe.png)    
**Added images in QSS_IMG folder**
 
Stay tunned!, this files are being updated frequently.
*Consider donating :)* **PayPal Account:** gtronick@gmail.com 

