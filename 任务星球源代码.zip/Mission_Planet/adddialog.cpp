//此为待办时间功能添加待办事件的对话框界面
#include "adddialog.h"
#include "ui_adddialog.h"
#include"widget_fixed.h"
#include"head_fixed.h"

addDialog::addDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::addDialog)
{


    ui->setupUi(this);
    // 设置 Tab 顺序，使 QLineEdit 优先接收焦点
        QDialog::setTabOrder(ui->fixednameEdit, ui->dateTimeEdit);
        this -> setWindowTitle("添加任务");
        this -> setFixedSize(450,600);
        this -> setWindowIcon(QIcon(":/image/Planet.png"));
        // 开启背景设置
        this->setAutoFillBackground(true);
        // 创建调色板对象
        QPalette p = this->palette();
        // 加载图片
        QPixmap pix(":/image/ADDBG.jpg");
        // 将背景图片大小调整为与窗口一致
        QPixmap fitPix = pix.scaled(this->size(), Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
        // 设置图片
        p.setBrush(QPalette::Window, QBrush(fitPix));
        this->setPalette(p);

    //编辑框置零
    ui->fixednameEdit->clear();
    ui->dateTimeEdit->setDisplayFormat("MM-dd hh:mm");
    ui->dateTimeEdit->setDateTime(QDateTime::currentDateTime());

}

addDialog::~addDialog()
{
    delete ui;
}

void addDialog::on_commitButton_fixed_clicked()
{
    QLabel *hintLabel;
    hintLabel=new QLabel(this);
    hintLabel->setText("请输入项目名称");
    int x = ui->fixednameEdit->x();
    int y = ui->fixednameEdit->y() + ui->fixednameEdit->height() + 5;
    hintLabel->move(x, y);
    hintLabel->setStyleSheet("QLabel {color: red;}");

    //读取lineEdit和timeEdit
    QString name=ui->fixednameEdit->text();
    QDateTime dateTime = ui->dateTimeEdit->dateTime();
    QString datetimeStr=dateTime.toString();
    if(ui->message_fixed->isChecked()){
        isTime=true;
    }

    if(name.isEmpty()){


        hintLabel->show();
    }
    else{
         hintLabel->hide();
    //插入数据
    QSqlDatabase db;
    if(QSqlDatabase::contains("qt_sql_default_connection"))
    {
        db = QSqlDatabase::database("qt_sql_default_connection");
    }
    else
    {
        db = QSqlDatabase::addDatabase("QSQLITE");
    }
     db.setDatabaseName("./fix.sqlite");
     if (!db.open()) {
         qDebug() << "Failed to connect to database!";
     } else {
         qDebug() << "Connected to database!";
     }
    QSqlQuery query;

    query.prepare("INSERT INTO item_fixed1(name, time, timer, checked) VALUES (:name, :time, :timer, :checked)");
    query.bindValue(":name", name);  // 替换为要插入的名称
    query.bindValue(":time", datetimeStr);  // 替换为要插入的时间
    query.bindValue(":timer", isTime?"true":"false");  // 替换为要插入的 timer 值
    query.bindValue(":checked", "false");  // 替换为要插入的 checked 值
    query.exec();



    emit nameEntered();
    //关闭当前窗口
    this->hide();

    }
}
