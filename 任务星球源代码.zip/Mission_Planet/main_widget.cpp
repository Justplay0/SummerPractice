//此为程序主界面
#include "main_widget.h"

Main_Widget::Main_Widget(QWidget *parent) : QWidget(parent)
{

    //主界面基础参数设置
    this -> setWindowTitle("任务星球");
    this -> setFixedSize(1600,900);
    this -> setWindowIcon(QIcon(":/image/Planet"));
    // 开启背景设置
    this->setAutoFillBackground(true);
    // 创建调色板对象
    QPalette p = this->palette();
    // 加载图片
    QPixmap pix(":/image/Night.png");
    // 将背景图片大小调整为与窗口一致
    QPixmap fitPix = pix.scaled(this->size(), Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    // 设置图片
    p.setBrush(QPalette::Window, QBrush(fitPix));
    this->setPalette(p);
    //“专注”按钮创建，
    QPushButton * TOCBTN = new QPushButton("专注",this);
    QString TOCBTN_Image = "://image//Tomato_Planet_Night.png";
    this -> setButtonImage(450,450,TOCBTN,TOCBTN_Image);
    TOCBTN -> move(480,295);
    //TOCBTN按钮连接getTomatoClock函数
    connect(TOCBTN,&QPushButton::clicked,this,&Main_Widget::getTomatoClock);


    //“待办”按钮创建
    QPushButton * TDLBTN = new QPushButton("待办",this);
    QString TDLBTN_Image = "://image//Mission_Planet_Night.png";
    this -> setButtonImage(400,350,TDLBTN,TDLBTN_Image);
    TDLBTN -> move(850,70);
    //TDLBTN按钮连接getToDoList函数；
    connect(TDLBTN,&QPushButton::clicked,this,&Main_Widget::getToDoList);


    //“我的星球”按钮创建
    QPushButton * ACTBTN = new QPushButton("我的星球",this);
    QString ACTBTN_Image = ":/image//Achievement_Planet_Night.png";
    this -> setButtonImage(270,210,ACTBTN,ACTBTN_Image);
    ACTBTN -> move(375,283);
    //ACTBTN按钮连接getAccomplishment函数
    connect(ACTBTN,&QPushButton::clicked,this,&Main_Widget::getAccomplishment);
    this->setAttribute(Qt::WA_DeleteOnClose);//子窗口关闭即销毁
    QSqlDatabase db;
    if(QSqlDatabase::contains("qt_sql_default_connection"))
    {
        db = QSqlDatabase::database("qt_sql_default_connection");
    }
    else
    {
        db = QSqlDatabase::addDatabase("QSQLITE");
    }
    db.setDatabaseName("./userTask.db");
    db.open();
    QSqlQuery query_tomato(db);
    query_tomato.exec("create table sqlinter(count)");
    db.close();
}

//关闭本界面，显示番茄钟界面
inline void Main_Widget::getTomatoClock()
{
    this->close();
    TC -> show();
}

//关闭本界面，显示待办事项界面
inline void Main_Widget::getToDoList()
{
    this -> close();
    TDL -> show();
}

//显示成就界面
inline void Main_Widget::getAccomplishment()
{
    AC -> show();
}


void Main_Widget::setButtonImage(int width,int height,QPushButton *button, QString image)
{
    button->setText("");
    QPixmap pixmap(image);
    QPixmap fitpixmap = pixmap.scaled(width, height, Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    button->setIcon(QIcon(fitpixmap));
    button->setIconSize(QSize(width, height));
    button->setFlat(true);
    button->setStyleSheet("border: 0px"); //消除边框
}




