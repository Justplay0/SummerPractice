//此为专注任务清单界面
#include "myconcentrationmainwindow.h"
#include "ui_myconcentrationmainwindow.h"
#include "main_widget.h"
#include "formfball.h"
#include "myhistorydialog.h"

MyConcentrationMainWindow::MyConcentrationMainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MyConcentrationMainWindow)
{
    this -> setWindowIcon(QIcon(":/image/Planet"));
    this -> setWindowTitle("专注星球");
    ui->setupUi(this);
    //连接“添加”和“展现widget添加界面”
    connect(ui->mainWindow_addNewBtn,&QPushButton::clicked,this,&MyConcentrationMainWindow::triggered_CreateNewWidget);
    Heard_updateMainWindow();
    //连接开始按钮与悬浮窗计时专注界面
    connect(this->ui->labelStart_1,&QPushButton::clicked,[=](){
            QSqlDatabase db;
            if(QSqlDatabase::contains("qt_sql_default_connection"))
            {
                db = QSqlDatabase::database("qt_sql_default_connection");
            }
            else
            {
                db = QSqlDatabase::addDatabase("QSQLITE");
            }
            db.setDatabaseName("./userTask.db");
            db.open();
            QSqlQuery query;
            query.exec("select * from userTask where ROWID = 1");
            QString taskName = "null";
            int taskTime = 0;
            if(query.next())
            {
                taskName = query.value("name").toString();
                taskTime = query.value("time").toInt();
            }
            this->close();
            FBW = new FBallWidget(taskName,taskTime);
            FBW->show();
            db.close();
        });
        connect(this->ui->labelStart_2,&QPushButton::clicked,[=](){
            QSqlDatabase db;
            if(QSqlDatabase::contains("qt_sql_default_connection"))
            {
                db = QSqlDatabase::database("qt_sql_default_connection");
            }
            else
            {
                db = QSqlDatabase::addDatabase("QSQLITE");
            }
            db.setDatabaseName("./userTask.db");
            db.open();
            QSqlQuery query;
            query.exec("select * from userTask where ROWID = 2");
            QString taskName = "null";
            int taskTime = 0;
            if(query.next())
            {
                taskName = query.value("name").toString();
                taskTime = query.value("time").toInt();
            }
            this->close();
            FBW = new FBallWidget(taskName,taskTime);
            FBW->show();
            db.close();
        });
        connect(this->ui->labelStart_3,&QPushButton::clicked,[=](){
            QSqlDatabase db;
            if(QSqlDatabase::contains("qt_sql_default_connection"))
            {
                db = QSqlDatabase::database("qt_sql_default_connection");
            }
            else
            {
                db = QSqlDatabase::addDatabase("QSQLITE");
            }
            db.setDatabaseName("./userTask.db");
            db.open();
            QSqlQuery query;
            query.exec("select * from userTask where ROWID = 3");
            QString taskName = "null";
            int taskTime = 0;
            if(query.next())
            {
                taskName = query.value("name").toString();
                taskTime = query.value("time").toInt();
            }
            this->close();
            FBW = new FBallWidget(taskName,taskTime);
            FBW->show();
            db.close();
        });
        connect(this->ui->labelStart_4,&QPushButton::clicked,[=](){
                QSqlDatabase db;
                if(QSqlDatabase::contains("qt_sql_default_connection"))
                {
                    db = QSqlDatabase::database("qt_sql_default_connection");
                }
                else
                {
                    db = QSqlDatabase::addDatabase("QSQLITE");
                }
                db.setDatabaseName("./userTask.db");
                db.open();
                QSqlQuery query;
                query.exec("select * from userTask where ROWID = 4");
                QString taskName = "null";
                int taskTime = 0;
                if(query.next())
                {
                    taskName = query.value("name").toString();
                    taskTime = query.value("time").toInt();
                }
                this->close();
                FBW = new FBallWidget(taskName,taskTime);
                FBW->show();
                db.close();
            });
            connect(this->ui->labelStart_5,&QPushButton::clicked,[=](){
                QSqlDatabase db;
                if(QSqlDatabase::contains("qt_sql_default_connection"))
                {
                    db = QSqlDatabase::database("qt_sql_default_connection");
                }
                else
                {
                    db = QSqlDatabase::addDatabase("QSQLITE");
                }
                db.setDatabaseName("./userTask.db");
                db.open();
                QSqlQuery query;
                query.exec("select * from userTask where ROWID = 5");
                QString taskName = "null";
                int taskTime = 0;
                if(query.next())
                {
                    taskName = query.value("name").toString();
                    taskTime = query.value("time").toInt();
                }
                this->close();
                FBW = new FBallWidget(taskName,taskTime);
                FBW->show();
                db.close();
            });
            connect(this->ui->labelStart_6,&QPushButton::clicked,[=](){
                QSqlDatabase db;
                if(QSqlDatabase::contains("qt_sql_default_connection"))
                {
                    db = QSqlDatabase::database("qt_sql_default_connection");
                }
                else
                {
                    db = QSqlDatabase::addDatabase("QSQLITE");
                }
                db.setDatabaseName("./userTask.db");
                db.open();
                QSqlQuery query;
                query.exec("select * from userTask where ROWID = 6");
                QString taskName = "null";
                int taskTime = 0;
                if(query.next())
                {
                    taskName = query.value("name").toString();
                    taskTime = query.value("time").toInt();
                }
                this->close();
                FBW = new FBallWidget(taskName,taskTime);
                FBW->show();
                db.close();
            });
            connect(this->ui->labelStart_7,&QPushButton::clicked,[=](){
                QSqlDatabase db;
                if(QSqlDatabase::contains("qt_sql_default_connection"))
                {
                    db = QSqlDatabase::database("qt_sql_default_connection");
                }
                else
                {
                    db = QSqlDatabase::addDatabase("QSQLITE");
                }
                db.setDatabaseName("./userTask.db");
                db.open();
                QSqlQuery query;
                query.exec("select * from userTask where ROWID = 7");
                QString taskName = "null";
                int taskTime = 0;
                if(query.next())
                {
                    taskName = query.value("name").toString();
                    taskTime = query.value("time").toInt();
                }
                this->close();
                FBW = new FBallWidget(taskName,taskTime);
                FBW->show();
                db.close();
            });

    //创建窗口后，除了刷新，还要让按钮有用啊
    connect(ui->labelDelete_1,&QPushButton::clicked,[=](){
        //按下第1个删除按钮
        QSqlDatabase db;
        if(QSqlDatabase::contains("qt_sql_default_connection"))
        {
            db = QSqlDatabase::database("qt_sql_default_connection");
        }
        else
        {
            db = QSqlDatabase::addDatabase("QSQLITE");
        }
        db.setDatabaseName("./userTask.db");
        db.open();
        QSqlQuery query;
        query.exec("Delete from userTask where ROWID = 1");
        db.close();
        updateDatabase();
        Heard_updateMainWindow();
    });
    connect(ui->labelDelete_2,&QPushButton::clicked,[=](){
        //按下第2个删除按钮
        QSqlDatabase db;
        if(QSqlDatabase::contains("qt_sql_default_connection"))
        {
            db = QSqlDatabase::database("qt_sql_default_connection");
        }
        else
        {
            db = QSqlDatabase::addDatabase("QSQLITE");
        }
        db.setDatabaseName("./userTask.db");
        db.open();
        QSqlQuery query;
        query.exec("Delete from userTask where ROWID = 2");
        db.close();
        updateDatabase();
        Heard_updateMainWindow();
    });
    connect(ui->labelDelete_3,&QPushButton::clicked,[=](){
        //按下第3个删除按钮
        QSqlDatabase db;
        if(QSqlDatabase::contains("qt_sql_default_connection"))
        {
            db = QSqlDatabase::database("qt_sql_default_connection");
        }
        else
        {
            db = QSqlDatabase::addDatabase("QSQLITE");
        }
        db.setDatabaseName("./userTask.db");
        db.open();
        QSqlQuery query;
        query.exec("Delete from userTask where ROWID = 3");
        db.close();
        updateDatabase();
        Heard_updateMainWindow();
    });
    connect(ui->labelDelete_4,&QPushButton::clicked,[=](){
        //按下第4个删除按钮
        QSqlDatabase db;
        if(QSqlDatabase::contains("qt_sql_default_connection"))
        {
            db = QSqlDatabase::database("qt_sql_default_connection");
        }
        else
        {
            db = QSqlDatabase::addDatabase("QSQLITE");
        }
        db.setDatabaseName("./userTask.db");
        db.open();
        QSqlQuery query;
        query.exec("Delete from userTask where ROWID = 4");
        db.close();
        updateDatabase();
        Heard_updateMainWindow();
    });
    connect(ui->labelDelete_5,&QPushButton::clicked,[=](){
        //按下第5个删除按钮
        QSqlDatabase db;
        if(QSqlDatabase::contains("qt_sql_default_connection"))
        {
            db = QSqlDatabase::database("qt_sql_default_connection");
        }
        else
        {
            db = QSqlDatabase::addDatabase("QSQLITE");
        }
        db.setDatabaseName("./userTask.db");
        db.open();
        QSqlQuery query;
        query.exec("Delete from userTask where ROWID = 5");
        db.close();
        updateDatabase();
        Heard_updateMainWindow();
    });
    connect(ui->labelDelete_6,&QPushButton::clicked,[=](){
        //按下第6个删除按钮
        QSqlDatabase db;
        if(QSqlDatabase::contains("qt_sql_default_connection"))
        {
            db = QSqlDatabase::database("qt_sql_default_connection");
        }
        else
        {
            db = QSqlDatabase::addDatabase("QSQLITE");
        }
        db.setDatabaseName("./userTask.db");
        db.open();
        QSqlQuery query;
        query.exec("Delete from userTask where ROWID = 6");
        db.close();
        updateDatabase();
        Heard_updateMainWindow();
    });
    connect(ui->labelDelete_7,&QPushButton::clicked,[=](){
        //按下第7个删除按钮
        QSqlDatabase db;
        if(QSqlDatabase::contains("qt_sql_default_connection"))
        {
            db = QSqlDatabase::database("qt_sql_default_connection");
        }
        else
        {
            db = QSqlDatabase::addDatabase("QSQLITE");
        }
        db.setDatabaseName("./userTask.db");
        db.open();
        QSqlQuery query;
        query.exec("Delete from userTask where ROWID = 7");
        db.close();
        updateDatabase();
        Heard_updateMainWindow();
    });
    //连接返回按钮与返回主界面函数
    connect(this->ui->mainWindow_returnBtn,&QPushButton::clicked,this,&MyConcentrationMainWindow::getMainWindow);
    //连接历史数据按钮与查看历史数据窗口
    connect(this->ui->mainWindow_historyBtn,&QPushButton::clicked,this,&MyConcentrationMainWindow::clicked_generateHistoryDialog);
}

MyConcentrationMainWindow::~MyConcentrationMainWindow()
{
    delete ui;
}

void MyConcentrationMainWindow::Heard_updateMainWindow()
{
    //先创建vec去获取数据库中的数据
    //QString的vec
    QVector<QString> taskNameVector;
    //int的vec
    QVector<int> taskTimeVector;
    //int的vec
    QVector<int> focusTimeVector;
    //打开数据库 userTast
    QSqlDatabase db;
    if(QSqlDatabase::contains("qt_sql_default_connection"))
    {
        db = QSqlDatabase::database("qt_sql_default_connection");
    }
    else
    {
        db = QSqlDatabase::addDatabase("QSQLITE");
    }
    db.setDatabaseName("./userTask.db");
    db.open();
    QSqlQuery query(db);
    query.exec("Select * from userTask");
    while(query.next())
    {
        QString taskName = query.value("name").toString();
        int taskTime = query.value("time").toInt();
        int focusTime = query.value("focustime").toInt();
        taskNameVector<<taskName;
        taskTimeVector<<taskTime;
        focusTimeVector<<focusTime;
    }

    //数据库关闭
    db.close();

    //按钮初始都无，看不见 hide，用不了 disable
    for(int i=1;i<=7;i++)
    {
        QPushButton* buttonStart = ui->centralWidget->findChild<QPushButton*>("labelStart_"+QString::number(i));
        QPushButton* buttonDelete = ui->centralWidget->findChild<QPushButton*>("labelDelete_"+QString::number(i));
        buttonStart->setEnabled(false);
        buttonDelete->setEnabled(false);
        buttonStart->hide();
        buttonDelete->hide();
    }

    //更新界面，主要通过找到相关的label，前面设置显示文字，后面隐藏，超过了7个会报错
    //假设我有vec 3个数据 size得到3 label 1~3 改文字
    for(int i=1;i<=taskNameVector.size();i++)
    {
        //上半部分有效，label显示，按钮有效
        QLabel *label = ui->centralWidget->findChild<QLabel *>("taskLabel_" + QString::number(i));
        QPushButton* buttonStart = ui->centralWidget->findChild<QPushButton*>("labelStart_"+QString::number(i));
        QPushButton* buttonDelete = ui->centralWidget->findChild<QPushButton*>("labelDelete_"+QString::number(i));
        label->show();
        label->setText(QString("  %1\t\t专注时长: %2分钟").arg(taskNameVector[i-1]).arg(taskTimeVector[i-1]));
        //将显示出来的“开始”按钮，连接到对应时间的悬浮窗计时
        QString taskName = taskNameVector[i - 1];
        int taskTime = taskTimeVector[i - 1];
        buttonStart->setEnabled(true);
        buttonDelete->setEnabled(true);
        buttonStart->show();
        buttonDelete->show();
    }
    //label 4~7 置空
    for(int i=taskNameVector.size()+1;i<=7;i++)
    {
        QLabel *label = ui->centralWidget->findChild<QLabel *>("taskLabel_" + QString::number(i));
        label->hide();
    }
}

//点击“添加”后创建widget界面，函数实现
void MyConcentrationMainWindow::triggered_CreateNewWidget()
{
    //先判断是否大于7个，再打开界面
    //创建vector存放userTask中的taskname
    QVector<QString> nameVector;
    //数据库读取
    QSqlDatabase db;
    if(QSqlDatabase::contains("qt_sql_default_connection"))
    {
        db = QSqlDatabase::database("qt_sql_default_connection");
    }
    else
    {
        db = QSqlDatabase::addDatabase("QSQLITE");
    }
    db.setDatabaseName("./userTask.db");
    db.open();
    QSqlQuery query(db);
    query.exec("Select * from userTask");
    while(query.next())
    {
        QString taskName = query.value("name").toString();
        nameVector << taskName;
    }
    //现在测试用
    qDebug()<<nameVector.size();
    qDebug()<<nameVector;
    //判断
    //如果大于等于7，警告后退出  ！！！！这里测试就不return了，后面记得加上
    if(nameVector.size()>=7)
    {
        QMessageBox::warning(this,"警告","您制定的任务数已经达到上限，请清理后再使用");
        return;
    }
    //没达到7，就正常开始界面
    AddNew_Widget *aw = new AddNew_Widget();
    aw->show();
    //如果打开了界面，那就 监听“刷新信号”和“刷新”
    connect(aw,&AddNew_Widget::AddNewAskUpdate,this,&MyConcentrationMainWindow::Heard_updateMainWindow);
}

//“刷新数据库表单”函数，重新分配uid，函数声明
void MyConcentrationMainWindow::updateDatabase()

{
    //打开数据库
    QSqlDatabase db;
    QSqlQuery *query;
    if(QSqlDatabase::contains("qt_sql_default_connection"))
    {
        db = QSqlDatabase::database("qt_sql_default_connection");
    }
    else
    {
        db = QSqlDatabase::addDatabase("QSQLITE");
    }
    db.setDatabaseName("./userTask.db");
    db.open();
    //创建query操作
    query = new QSqlQuery();
    //1.创建新表
    //2.删除新表数据
    //3.向新表插入所有数据
    //4.删除原表
    //5.新表命名为原表
    query->exec("create table userTask_temp(name,time,focustime)");
    query->exec("delete from userTask_temp");
    query->exec("insert into userTask_temp select * from userTask");
    query->exec("Drop table userTask");
    query->exec("alter table userTask_temp rename to userTask");
    db.close();
}
inline void MyConcentrationMainWindow::getMainWindow()
{
    Main_Widget * MWT = new Main_Widget;
    this->close();
    MWT->show();
}


void MyConcentrationMainWindow::clicked_generateHistoryDialog()
{
    //点一下“历史数据”，生成w，w是dialog，dialog有chistogram成员，成员会依附到dialog上面。
    //如果传空参，那么什么都不会生成
    //现在要调用数据库传入三个参数，1.int maximumUpCount，最大上标（相近于 最大总次数）
    //2.taskNameVector QString类型的任务名vector
    //3.taskCountVector int类型的y轴次数，就是一个任务的总次数
    //1 3都需要总次数，需要悬浮窗实现
    //4.nullCount 即空的次数

    //2可以直接获取，如下
    QVector<QString> taskNameVector;
    QVector<int>focusTimeVector;
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("userTask.db");
    db.open();
    QSqlQuery query;
    query.exec("Select * from userTask");
    while(query.next())
    {
        QString taskName = query.value("name").toString();
        int focusTime = query.value("focustime").toInt();
        taskNameVector << taskName;
        focusTimeVector << focusTime;

    }
    int nullCount = 7-taskNameVector.size();

    //taskNameVector即传入的QString类型的任务名vector
    int maxVal = 0;
    if(taskNameVector.size()>=2)
    {
        maxVal = focusTimeVector[0];
        for(int i=1;i<focusTimeVector.size();i++)
        {
            if(focusTimeVector[i]>maxVal)
            {
                maxVal = focusTimeVector[i];
            }
        }
    }
    else if(taskNameVector.size()==1)
    {
        maxVal = focusTimeVector[0];
    }

    myHistoryDialog *w = new myHistoryDialog(maxVal,taskNameVector,focusTimeVector,nullCount);
    w -> setWindowIcon(QIcon(":/image/Planet"));
    w -> setWindowTitle("历史数据");
    w ->  setFixedSize(1200,800);
    w->show();
}
