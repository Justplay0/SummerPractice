#ifndef HEAD_FIXED_H
#define HEAD_FIXED_H
#include<QObject>
#include <QDebug>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include<QMessageBox>
#include<QDateTime>
#include<QString>
#include<QLabel>
#include<QHBoxLayout>
#include<QVBoxLayout>
#include <QToolButton>
#include<QCheckBox>
#include <QTimer>
#endif // HEAD_FIXED_H

