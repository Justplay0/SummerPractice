//该类为拓展功能-添加音效模块，模块与接口已完成，但由于时间限制以及考虑到番茄钟程序用户对声音没有需求，且短时间内找不到合适的舒缓音效，因而在本次发布的1.0版本中没有加入该功能，
//并且音频资源内存过大，上传不太方便。

//用qt自带的类创建一个可以插入音效的对象，设置音效文件的地址，音量，循环次数，开始播放，封装成静态函数以便其他类可直接通过类名和函数名调用函数

#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);

    //changeWindowSound();
    clickSound1();
}

Widget::~Widget()
{
    delete ui;
}

void Widget::changeWindowSound1()
{
    QSoundEffect* music = new QSoundEffect();
    music->setSource(QUrl::fromLocalFile(":/music/xiu1.wav"));
    music->setVolume(0.25f);
    music->setLoopCount(1);
    music->play();
}

void Widget::changeWindowSound2()
{
    QSoundEffect* music = new QSoundEffect();
    music->setSource(QUrl::fromLocalFile(":/music/xiu2.wav"));
    music->setVolume(0.25f);
    music->setLoopCount(1);
    music->play();
}

void Widget::changeWindowSound3()
{
    QSoundEffect* music = new QSoundEffect();
    music->setSource(QUrl::fromLocalFile(":/music/xiu3.wav"));
    music->setVolume(0.25f);
    music->setLoopCount(1);
    music->play();
}

void Widget::changeWindowSound4()
{
    QSoundEffect* music = new QSoundEffect();
    music->setSource(QUrl::fromLocalFile(":/music/xiu4.wav"));
    music->setVolume(0.25f);
    music->setLoopCount(1);
    music->play();
}

void Widget::changeWindowSound5()
{
    QSoundEffect* music = new QSoundEffect();
    music->setSource(QUrl::fromLocalFile(":/music/xiu5.wav"));
    music->setVolume(0.25f);
    music->setLoopCount(1);
    music->play();
}

void Widget::changeWindowSound6()
{
    QSoundEffect* music = new QSoundEffect();
    music->setSource(QUrl::fromLocalFile(":/music/xiu6.wav"));
    music->setVolume(0.25f);
    music->setLoopCount(1);
    music->play();
}

void Widget::changeWindowSound7()
{
    QSoundEffect* music = new QSoundEffect();
    music->setSource(QUrl::fromLocalFile(":/music/fly.wav"));
    music->setVolume(0.25f);
    music->setLoopCount(1);
    music->play();
}


void Widget::clickSound1()
{
    QSoundEffect* music = new QSoundEffect();
    music->setSource(QUrl::fromLocalFile(":/music/click.wav"));
    music->setVolume(0.25f);
    music->setLoopCount(1);
    music->play();
}

void Widget::clickSound2()
{
    QSoundEffect* music = new QSoundEffect();
    music->setSource(QUrl::fromLocalFile(":/music/click1.wav"));
    music->setVolume(0.25f);
    music->setLoopCount(1);
    music->play();
}

void Widget::clickSound3()
{
    QSoundEffect* music = new QSoundEffect();
    music->setSource(QUrl::fromLocalFile(":/music/click2.wav"));
    music->setVolume(0.25f);
    music->setLoopCount(1);
    music->play();
}

void Widget::clickSound4()
{
    QSoundEffect* music = new QSoundEffect();
    music->setSource(QUrl::fromLocalFile(":/music/click3.wav"));
    music->setVolume(0.25f);
    music->setLoopCount(1);
    music->play();
}

void Widget::clickSound5()
{
    QSoundEffect* music = new QSoundEffect();
    music->setSource(QUrl::fromLocalFile(":/music/click4.wav"));
    music->setVolume(0.25f);
    music->setLoopCount(1);
    music->play();
}

void Widget::clickSound6()
{
    QSoundEffect* music = new QSoundEffect();
    music->setSource(QUrl::fromLocalFile(":/music/click5.wav"));
    music->setVolume(0.25f);
    music->setLoopCount(1);
    music->play();
}

void Widget::countdown()
{
    QSoundEffect* music = new QSoundEffect();
    music->setSource(QUrl::fromLocalFile(":/music/countdown.wav"));
    music->setVolume(0.25f);
    music->setLoopCount(1);
    music->play();
}
