#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include<QSoundEffect>

QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    void changeWindowSound1();
    void changeWindowSound2();
    void changeWindowSound3();
    void changeWindowSound4();
    void changeWindowSound5();
    void changeWindowSound6();
    void changeWindowSound7();
    void clickSound1();
    void clickSound2();
    void clickSound3();
    void clickSound4();
    void clickSound5();
    void clickSound6();
    void countdown();
    ~Widget();

private:
    Ui::Widget *ui;
    //QSoundEffect *music;
};
#endif // WIDGET_H
