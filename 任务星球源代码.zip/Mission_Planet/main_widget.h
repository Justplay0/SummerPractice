#ifndef MAIN_WIDGET_H
#define MAIN_WIDGET_H

#include "myconcentrationmainwindow.h"
#include "widget_fixed.h"
#include "myachievementwidget.h"
#include <QWidget>
#include <QPushButton>‘

class Main_Widget : public QWidget
{
    Q_OBJECT
public:
    explicit Main_Widget(QWidget *parent = nullptr);

protected:
    inline void getAccomplishment();
    inline void getTomatoClock();
    inline void getToDoList();
    void setButtonImage_BigSize(QPushButton *button, QString image);
    void setButtonImage_SmallSize(QPushButton *button, QString image);
    void setButtonImage(int width,int height,QPushButton * button,QString image);
    Widget_fixed * TDL = new Widget_fixed;
    MyConcentrationMainWindow * TC = new MyConcentrationMainWindow;
    myAchievementWidget * AC = new myAchievementWidget;
signals:

public slots:
};

#endif // MAIN_WIDGET_H

